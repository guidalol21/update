-- main tab
VERSION = "1.3"

UI.Label("Config version: " .. VERSION)

UI.Separator()



UI.Separator()

UI.Button("Discord", function()
  g_platform.openUrl("https://discord.gg/ATjpsWyB3k")
end)

UI.Button("Forum", function()
  g_platform.openUrl("https://discord.gg/ATjpsWyB3k")
end)

UI.Button("Help & Tutorials", function()
  g_platform.openUrl("https://discord.gg/ATjpsWyB3k")
end)
