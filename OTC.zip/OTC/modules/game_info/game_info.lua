--Lista de offsets para cada Outfit.
local OutfitOffsets = {
    [583] = {
        [North] = {x = -58, y = -55},
        [East] = {x = -58, y = -55},
        [South] = {x = -58, y = -55},
        [West] = {x = -58, y = -55},
    }
}


local function translateDir(dir)
    if dir == NorthEast or dir == SouthEast then
        return East
    elseif dir == NorthWest or dir == SouthWest then
        return West
    end
    return dir
end

local function getOutfitInformationOffset(outfit, dir)
    if OutfitOffsets[outfit] then
        return OutfitOffsets[outfit][translateDir(dir)]
    end
    return {x = -4, y = -15}
end

local function onCreatureAppear(creature)
    local Offset = getOutfitInformationOffset(creature:getOutfit().type, creature:getDirection())
    creature:setInformationOffset(Offset.x, Offset.y)
end

local function onCreatureDirectionChange(creature, oldDirection, newDirection)
    local Offset = getOutfitInformationOffset(creature:getOutfit().type, newDirection)
    creature:setInformationOffset(Offset.x, Offset.y)
end

local function onCreatureOutfitChange(creature, newOutfit, oldOutfit)
    local Offset = getOutfitInformationOffset(newOutfit.type, creature:getDirection())
    creature:setInformationOffset(Offset.x, Offset.y)
end

function init()
    connect(LocalPlayer, {onOutfitChange = onCreatureOutfitChange})
    connect(Creature, {
        onAppear = onCreatureAppear,
        onDirectionChange = onCreatureDirectionChange,
        onOutfitChange = onCreatureOutfitChange
    })
end

function terminate()
    disconnect(LocalPlayer, {onOutfitChange = onCreatureOutfitChange})
    disconnect(Creature, {
        onAppear = onCreatureAppear,
        onDirectionChange = onCreatureDirectionChange,
        onOutfitChange = onCreatureOutfitChange
    })
end