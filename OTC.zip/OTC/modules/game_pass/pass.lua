local buttonPass = nil 
local passWindow = nil
local buyPassUpgrade = nil
local buyLevelUp = nil
local receiveOpcodePass = 11
local passList = nil
local event = nil

function init()
    connect(g_game, {
        onGameStart = naoexibir,
        onGameEnd = naoexibir,
    })

    buttonPass = modules.client_topmenu.addLeftGameToggleButton('buttonPass', tr('Passe de batalha'), '/data/images/topbuttons/battle', exibir)
    buttonPass:setWidth(34)
    buttonPass:setOn(false)

    passWindow = g_ui.loadUI("pass", modules.game_interface.getRootPanel())
    passList = passWindow:getChildById("passList")
    ProtocolGame.registerExtendedJSONOpcode(receiveOpcodePass, onReceivePass)
    passWindow:hide()
end

function terminate()
    disconnect(g_game, {
        onGameStart = naoexibir,
        onGameEnd = naoexibir,
    })

    ProtocolGame.unregisterExtendedJSONOpcode(receiveOpcodePass)
    naoexibir()
    buttonPass:setOn(false)
end


function exibir()
  if buttonPass:isOn() then
      buttonPass:setOn(false)
      naoexibir()
  else
      buttonPass:setOn(true)
      passWindow:show()
      g_game.getProtocolGame():sendExtendedOpcode(33, json.encode({type = "openPass"}))
  end
end

function naoexibir()
  if buyPassUpgrade then
      buyPassUpgrade:destroy()
      buyPassUpgrade = nil
  end

  if buyLevelUp then
      buyLevelUp:destroy()
      buyLevelUp = nil
  end
  
  if passWindow.MissionPanelInfo then
      passWindow.passPanel:setVisible(true)
      passWindow.MissionPanelInfo.missionScrollPanel:setVisible(false)
      passWindow.MissionPanelInfo.returnList:setVisible(false)
      passWindow.MissionPanelInfo.scrollBarTask:setVisible(false)
      passWindow.MissionPanelInfo.missionScrollPanel:destroyChildren()
      passWindow.MissionPanelInfo.panelDescriptionMission:destroyChildren()
      g_game.getProtocolGame():sendExtendedOpcode(33, json.encode({type = "openPass"}))
  end
  buttonPass:setOn(false)
  passWindow:hide()
  removeEventPass()
end

function getCurrentDateString()
    local currentDate = os.date("*t")
    return string.format("%02d/%02d/%04d", currentDate.day, currentDate.month, currentDate.year)
end

function getCurrentDay()
    local currentTime = os.time()
    local dateTable = os.date("*t", currentTime)
    return dateTable.day
end

function countdown(finaly)

    if type(finaly) == "table" then
        finaly = os.time(finaly)
    end

    removeEventPass()

    local days, hours, minutes, seconds = getTime(finaly)
    local formattedTime = string.format("%d dias, %02d horas, %02d minutos, %02d segundos", days, hours, minutes, seconds)
    passWindow.passPanel.labelFinal:setText("Tempo restante: {" .. formattedTime .. "#03cffc}")

    event = cycleEvent(function()
        local endTime = finaly
        local currentTime = os.time()
        local difference = endTime - currentTime

        local passEndFormatado = os.date("%Y-%m-%d %H:%M:%S", endTime)

        if difference <= 0 then
            passWindow.passPanel.labelFinal:setText("Finalizou: {" .. passEndFormatado .. "#FF0000}")
            return "Passe finalizado!"
        end

        local days, hours, minutes, seconds = getTime(finaly)
        local formattedTime = string.format("%d dias, %02d horas, %02d minutos, %02d segundos", days, hours, minutes, seconds)

        passWindow.passPanel.labelFinal:setFont("font-size13")
        passWindow.passPanel.labelFinal:setText("Tempo restante: {" .. formattedTime .. "#03cffc}")
        local highlightData = getNewHighlightedText(passWindow.passPanel.labelFinal:getText(), "#ffffff", "#03cffc")
        if #highlightData > 2 then
            passWindow.passPanel.labelFinal:setColoredText(highlightData)
        end
    end, 1000)
end

function removeEventPass()
    if event then
        removeEvent(event)
        event = nil
    end
end

function getTime(finaly)
    local endTime = finaly
    local currentTime = os.time()
    local difference = endTime - currentTime

    local days = math.floor(difference / (24 * 3600))
    difference = difference % (24 * 3600)
    local hours = math.floor(difference / 3600)
    difference = difference % 3600
    local minutes = math.floor(difference / 60)
    local seconds = difference % 60

    return days, hours, minutes, seconds
end

function onReceivePass(protocol, opcode, json_data)
  if json_data.type == "openPass" then

    --  desativar o painel de miss�es ao abrir o passe
    passWindow.MissionPanelInfo.missionScrollPanel:setVisible(false)
    passWindow.MissionPanelInfo.returnList:setVisible(false)
    passWindow.passPanel.listPanel.basic:destroyChildren()
    passWindow.passPanel.listPanel.premium:destroyChildren()
    passWindow.passPanel.panelDescription:destroyChildren()

    local description = g_ui.createWidget("DescriptionLabel", passWindow.passPanel.panelDescription)
    description:setFont("font-size13")
    description:setText("{Entre na aventura ninja!#03cffc} Complete {miss�es desafiadoras#ff4500} e colete {pr�mios lend�rios#ff4500} no {Passe de Batalha Shinobi#03cffc}! A cada 5 itens encontrados, o quinto ser� sempre um item {LEND�RIO#03cffc}. Boa sorte, {shinobi#ff4500}!")

    local highlightData = getNewHighlightedText(description:getText(), "#ffffff", "#03cffc")
    if #highlightData > 2 then
        description:setColoredText(highlightData)
    end

    countdown(json_data.passData.passEnd)
    passWindow.passPanel.labelLevel:setFont("font-size13")
    passWindow.passPanel.labelLevel:setText("Pass level: {" ..json_data.passData.level.. "#03cffc}")
    local highlightData = getNewHighlightedText(passWindow.passPanel.labelLevel:getText(), "#ffffff", "red")
    if #highlightData > 2 then
        passWindow.passPanel.labelLevel:setColoredText(highlightData)
    end

    -- button Passe
    local basicCount, eliteCount = countAvailableRewards(json_data.passData)
    if (basicCount >= 3) or (basicCount >= 1 and json_data.passData.status == 1) then
        passWindow.passPanel.buttonCollect:setVisible(true)
    else
        passWindow.passPanel.buttonCollect:setVisible(false)
    end


    passWindow.passPanel.buttonCollect.onClick = function()
        g_game.getProtocolGame():sendExtendedOpcode(33, json.encode({type = "collectAllReward"}))
    end

    buyPass(json_data.passData.UpgradePass, json_data.passData.status, json_data.passData)
    buyLevel(json_data.passData.levelUp)

    passWindow.passPanel.ProgressBar:setValue(json_data.passData.exp, 0, 100)
    passWindow.passPanel.ProgressBar:setText(json_data.passData.exp.."%")
    passWindow.passPanel.ProgressBar:setTooltip(json_data.passData.exp.."% de experiencia")


    passWindow.passPanel.buttonTask.onClick = function()
        g_game.getProtocolGame():sendExtendedOpcode(33, json.encode({type = "updatePassMission"}))
        passWindow.passPanel:setVisible(false)
    end

    passWindow.MissionPanelInfo.returnList.onClick = function()
        passWindow.passPanel:setVisible(true)
        passWindow.MissionPanelInfo.missionScrollPanel:setVisible(false)
        passWindow.MissionPanelInfo.returnList:setVisible(false)
        passWindow.MissionPanelInfo.scrollBarTask:setVisible(false)
        passWindow.MissionPanelInfo.missionScrollPanel:destroyChildren()
        passWindow.MissionPanelInfo.panelDescriptionMission:destroyChildren()
        passWindow:setImageSource("images/background")
        g_game.getProtocolGame():sendExtendedOpcode(33, json.encode({type = "openPass"}))
    end

    for _, data in ipairs(json_data.passData.data) do
      if data.typePass == "Basic" then

        for basicIndex, itemData in ipairs(data.rewards) do
          local itemWidget = g_ui.createWidget("ItemPassWidget", passWindow.passPanel.listPanel.basic)
          itemWidget.item:setItemId(itemData.itemId)
          itemWidget.item:setTooltip(itemData.itemName)
          itemWidget.item.itemCount:setText(itemData.count)
          itemWidget.indexLabel:setText(itemData.index)
          
          itemWidget.item.onClick = function()
              g_game.getProtocolGame():sendExtendedOpcode(33, json.encode({type = "collectRewardPass", index = itemData.index, pass = data.typePass }))
          end

          if itemData.collect then
              itemWidget:setImageSource("images/imageitem_collect")
          else
              itemWidget:setImageSource("images/imageitem_basic")
          end

          if itemData.index <= json_data.passData.level then
              itemWidget:setEnabled(true)
          else
              itemWidget:setEnabled(false)
          end
        end
      elseif data.typePass == "Elite" then

        for basicIndex, itemData in ipairs(data.rewards) do
          local itemWidget = g_ui.createWidget("ItemPassWidget", passWindow.passPanel.listPanel.premium)
          itemWidget.item:setItemId(itemData.itemId)
          itemWidget.item:setTooltip(itemData.itemName)
          itemWidget.item.itemCount:setText(itemData.count)
          itemWidget.indexLabel:setText(itemData.index)


          itemWidget.item.onClick = function()
              g_game.getProtocolGame():sendExtendedOpcode(33, json.encode({type = "collectRewardPass", index = itemData.index, pass = data.typePass }))
          end

          if itemData.collect then
              itemWidget:setImageSource("images/imageitem_collect")
          else
              itemWidget:setImageSource("images/imageitem_elite")
          end

          if itemData.index <= json_data.passData.level and json_data.passData.status == 1 then
              itemWidget:setEnabled(true)
          else
              itemWidget:setEnabled(false)
          end
        end
      end
    end
elseif json_data.type == "missionUpdate" then
    passWindow.MissionPanelInfo.missionScrollPanel:setVisible(true)
    passWindow.MissionPanelInfo.returnList:setVisible(true)
    passWindow.MissionPanelInfo.scrollBarTask:setVisible(true)
    passWindow.MissionPanelInfo.missionScrollPanel:destroyChildren()
    passWindow.MissionPanelInfo.panelDescriptionMission:destroyChildren()
    passWindow:setImageSource("images/background_task")

    local description = g_ui.createWidget("DescriptionLabel", passWindow.MissionPanelInfo.panelDescriptionMission)
    description:setFont("font-size13")
    description:setText("{Aventura Ninja!#03cffc} Receba uma lista de 4 monstros com {booster e Penalty#ff4500}. Passe o mouse sobre o fogo para ver os detalhes. Boa sorte, {shinobi#ff4500}!")

    local highlightData = getNewHighlightedText(description:getText(), "#ffffff", "#03cffc")
    if #highlightData > 2 then
        description:setColoredText(highlightData)
    end

    for _, data in ipairs(json_data.missionData) do
      local mission = g_ui.createWidget("MissionPassPanel", passWindow.MissionPanelInfo.missionScrollPanel)


    if data.bonusMonsters == true then
        mission.monsterName:setText(data.name)
        mission.experiencia:setText("Exp: {" ..data.exp.."%#00E72F}")
        mission.monsterCount:setText("Matou: {" ..data.kill.."/"..data.count.. "#00E72F}")
        mission.outfit:setOutfit({type = data.outfit})
        mission.buttonBonus:setVisible(true)
        local expBonus = data.bonusInfo.expBonus
        local countBonus = data.bonusInfo.countBonus
        local timeUntilNextUpdateFormatted = string.format("%02d:%02d:%02d", data.timeUntilNextUpdate / 3600, (data.timeUntilNextUpdate % 3600) / 60, data.timeUntilNextUpdate % 60)
        local tooltip = "Monster Booster\n\n" ..
                        "Bonus exp: " .. expBonus .. "%\n" ..
                        "Penalty: +" .. countBonus .. " monsters\n" ..
                        "Next bonus reset: " .. timeUntilNextUpdateFormatted
        mission.buttonBonus:setTooltip(tooltip)
        local highlightData = getNewHighlightedText(mission.monsterCount:getText(), "#ffffff", "red")
        if #highlightData > 2 then
            mission.monsterCount:setColoredText(highlightData)
        end
        local highlightData = getNewHighlightedText(mission.experiencia:getText(), "#ffffff", "red")
        if #highlightData > 2 then
            mission.experiencia:setColoredText(highlightData)
        end
            mission:setImageSource("images/Mission_finish")
    else
        mission.monsterName:setText(data.name)
        mission.experiencia:setText("Exp: {" ..data.exp.."%#FF0000}")
        mission.monsterCount:setText("Matou: {" ..data.kill.."/"..data.count.. "#FF0000}")
        mission.outfit:setOutfit({type = data.outfit})
        local highlightData = getNewHighlightedText(mission.monsterCount:getText(), "#ffffff", "red")
        if #highlightData > 2 then
            mission.monsterCount:setColoredText(highlightData)
        end
        local highlightData = getNewHighlightedText(mission.experiencia:getText(), "#ffffff", "red")
        if #highlightData > 2 then
            mission.experiencia:setColoredText(highlightData)
        end
        mission:setImageSource("images/Mission")
    end
  

    if data.completed == 1 then
      mission.monsterName:setText(data.name)
      mission.experiencia:setText("Exp: {" ..data.exp.."%#00E72F}")
      mission.monsterCount:setText("Matou: {" ..data.kill.."/"..data.count.. "#00E72F}")
      mission.outfit:setOutfit({type = data.outfit})
      local highlightData = getNewHighlightedText(mission.monsterCount:getText(), "#ffffff", "red")
      if #highlightData > 2 then
          mission.monsterCount:setColoredText(highlightData)
      end
      local highlightData = getNewHighlightedText(mission.experiencia:getText(), "#ffffff", "red")
      if #highlightData > 2 then
          mission.experiencia:setColoredText(highlightData)
      end
          mission:setImageSource("images/Mission_finish")
      else
          mission.monsterName:setText(data.name)
          mission.experiencia:setText("Exp: {" ..data.exp.."%#FF0000}")
          mission.monsterCount:setText("Matou: {" ..data.kill.."/"..data.count.. "#FF0000}")
          mission.outfit:setOutfit({type = data.outfit})
          local highlightData = getNewHighlightedText(mission.monsterCount:getText(), "#ffffff", "red")
          if #highlightData > 2 then
              mission.monsterCount:setColoredText(highlightData)
          end
          local highlightData = getNewHighlightedText(mission.experiencia:getText(), "#ffffff", "red")
          if #highlightData > 2 then
              mission.experiencia:setColoredText(highlightData)
          end
          mission:setImageSource("images/Mission")
      end
    end
  end
end

function buyPass(valor, status, data)
    passWindow.passPanel.buttonElite.onClick = function()
  
      if buyPassUpgrade then
          buyPassUpgrade:destroy()
          buyPassUpgrade = nil
      end
  
      local msg, yesCallback
      yesCallback = function() 
        g_game.getProtocolGame():sendExtendedOpcode(33, json.encode({type = "BuyPass"}))
  
        if buyPassUpgrade then
          buyPassUpgrade:destroy()
        end
      end
  
      local noCallback = function()
        buyPassUpgrade:destroy()
      end
  
      if status == 1 then
        buyPassUpgrade = displayGeneralBox(
          tr('Passe de Elite'),
          tr("Voc� ja deu upgrade no seu passe"),
          {{ text=tr('Ok'), callback=noCallback },
          anchor=AnchorHorizontalCenter}, noCallback)
        return 
      end 
  
      local prompt = true
      if prompt then
        buyPassUpgrade = displayGeneralBox(
          tr('Upgrade Elite'),
          tr("Voc� confirma que deseja fazer o upgrade para o Passe Elite pagando " .. valor .. " pontos?"),
          {{ text=tr('Sim'), callback=yesCallback },
          { text=tr('N�o'), callback=noCallback },
          anchor=AnchorHorizontalCenter}, yesCallback, noCallback)
      end
    end
  end
  
  function buyLevel(valor)
    passWindow.passPanel.buttonUP.onClick = function()
  
      if buyLevelUp then
          buyLevelUp:destroy()
          buyLevelUp = nil
      end
  
      local msg, yesCallback
      yesCallback = function() 
        g_game.getProtocolGame():sendExtendedOpcode(33, json.encode({type = "buyLevel"}))
        if buyLevelUp then
          buyLevelUp:destroy()
        end
      end
  
      local noCallback = function()
        buyLevelUp:destroy()
      end
  
      local prompt = true
      if prompt then
        buyLevelUp = displayGeneralBox(
          tr('Passe LevelUp'),
          tr("Voc� confirma que deseja comprar um level UP para o seu passe gastando " .. valor .. " pontos?"),
          {{ text=tr('Sim'), callback=yesCallback },
          { text=tr('N�o'), callback=noCallback },
          anchor=AnchorHorizontalCenter}, yesCallback, noCallback)
      end
    end
  end
  
  function countAvailableRewards(passData)
      local basicCount = 0
      local eliteCount = 0
  
      for _, data in ipairs(passData.data) do
          for _, itemData in ipairs(data.rewards) do
              if itemData.index <= passData.level and not itemData.collect then
                  if data.typePass == "Elite" and passData.status == 1 then
                      eliteCount = eliteCount + 1
                  elseif data.typePass == "Basic" then
                      basicCount = basicCount + 1
                  end
              end
          end
      end
  
      return basicCount, eliteCount
  end